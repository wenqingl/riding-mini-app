App({
  onLaunch() {
    const envId = this.globalData.cloudEnvId;
    if (wx.cloud && envId) {
      wx.cloud.init({ env: envId });
    }
  },
  globalData: {
    baseUrl: 'https://your-domain.com',
    cloudEnvId: '',
    cloudServiceName: ''
  }
})
