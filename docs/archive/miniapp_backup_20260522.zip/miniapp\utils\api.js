let cloudInited = false;

const getAppConfig = () => {
  const app = getApp();
  return app && app.globalData ? app.globalData : {};
};

const getBaseUrl = () => getAppConfig().baseUrl;

const getCloudConfig = () => {
  const { cloudEnvId, cloudServiceName } = getAppConfig();
  if (!cloudEnvId || !cloudServiceName || !wx.cloud || !wx.cloud.callContainer) {
    return null;
  }
  if (!cloudInited) {
    wx.cloud.init({ env: cloudEnvId });
    cloudInited = true;
  }
  return { env: cloudEnvId, service: cloudServiceName };
};

const normalizeError = (res) => {
  const error = new Error(
    (res.data && res.data.detail) ? res.data.detail : 'Request failed'
  );
  error.statusCode = res.statusCode;
  error.data = res.data;
  return error;
};

const requestHttp = (path, options = {}) => {
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${getBaseUrl()}${path}`,
      ...options,
      success: res => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(res.data);
          return;
        }
        reject(normalizeError(res));
      },
      fail: err => reject(err)
    });
  });
};

const requestCloud = (path, options = {}, cloudConfig = {}) => {
  return new Promise((resolve, reject) => {
    wx.cloud.callContainer({
      config: { env: cloudConfig.env },
      path,
      method: options.method || 'GET',
      header: {
        ...(options.header || {}),
        'X-WX-SERVICE': cloudConfig.service
      },
      data: options.data,
      responseType: options.responseType,
      timeout: options.timeout,
      success: res => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(res.data);
          return;
        }
        reject(normalizeError(res));
      },
      fail: err => reject(err)
    });
  });
};

const request = (path, options = {}) => {
  const cloudConfig = getCloudConfig();
  if (cloudConfig) {
    return requestCloud(path, options, cloudConfig);
  }
  return requestHttp(path, options);
};

const api = {
  getRecords: (token) => request('/api/records', {
    method: 'GET',
    header: { Authorization: `Bearer ${token}` }
  }),

  mergeAndUpload: (data, token) => request('/api/merge-and-upload', {
    method: 'POST',
    header: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    data
  }),

  refreshToken: (refreshToken) => request(`/auth/refresh?refresh_token=${encodeURIComponent(refreshToken)}`, {
    method: 'POST'
  }),

  mergeDownload: async (data, token) => {
    const buffer = await request('/api/merge', {
      method: 'POST',
      header: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      data,
      responseType: 'arraybuffer'
    });
    const fs = wx.getFileSystemManager();
    const filePath = `${wx.env.USER_DATA_PATH}/merged.gpx`;
    return new Promise((resolve, reject) => {
      fs.writeFile({
        filePath,
        data: buffer,
        encoding: 'binary',
        success: () => resolve({ filePath }),
        fail: err => reject(err)
      });
    });
  },

  getRecordFile: (recordId, format, token) => {
    return new Promise((resolve, reject) => {
      wx.downloadFile({
        url: `${getBaseUrl()}/api/records/${recordId}/file?format=${format}`,
        header: { Authorization: `Bearer ${token}` },
        success: res => resolve(res),
        fail: err => reject(err)
      });
    });
  }
};

module.exports = api;
