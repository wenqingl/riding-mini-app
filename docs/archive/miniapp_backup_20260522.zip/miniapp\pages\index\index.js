const api = require('../../utils/api');

Page({
  data: {
    loggedIn: false,
    userName: '',
    records: [],
    selectedCount: 0,
    loading: false,
    merging: false,
    mergeResult: null,
    token: ''
  },

  onLoad() {
    const token = wx.getStorageSync('access_token');
    const userName = wx.getStorageSync('user_name') || '用户';
    if (token) {
      this.setData({ loggedIn: true, token, userName });
      this.loadRecords();
    }
  },

  onShow() {
    const token = wx.getStorageSync('access_token');
    const userName = wx.getStorageSync('user_name') || '鐢ㄦ埛';
    if (token && (!this.data.loggedIn || this.data.token !== token)) {
      this.setData({ loggedIn: true, token, userName });
      this.loadRecords();
    }
  },

  doLogin() {
    const app = getApp();
    const authUrl = `${app.globalData.baseUrl}/auth/login`;
    wx.setStorageSync('auth_url', authUrl);
    wx.navigateTo({ url: `/pages/webview/webview?url=${encodeURIComponent(authUrl)}` });
  },

  doLogout() {
    wx.removeStorageSync('access_token');
    wx.removeStorageSync('refresh_token');
    wx.removeStorageSync('user_name');
    this.setData({ loggedIn: false, token: '', records: [], mergeResult: null });
  },

  async refreshAccessToken() {
    const refreshToken = wx.getStorageSync('refresh_token');
    if (!refreshToken) return false;
    try {
      const res = await api.refreshToken(refreshToken);
      if (res && res.access_token) {
        wx.setStorageSync('access_token', res.access_token);
        this.setData({ token: res.access_token, loggedIn: true });
        return true;
      }
    } catch (e) {}
    return false;
  },

  async loadRecords(retried = false) {
    this.setData({ loading: true });
    try {
      const res = await api.getRecords(this.data.token);
      const records = (res.records || []).map(r => ({
        ...r,
        selected: false,
        date: r.start_time ? r.start_time.split('T')[0] : (r.date || ''),
        distance: r.distance ? (r.distance / 1000).toFixed(1) : '0',
        duration: r.duration ? this.formatDuration(r.duration) : '00:00:00',
      }));
      this.setData({ records, loading: false });
    } catch (e) {
      if (!retried && e && e.statusCode === 401) {
        const refreshed = await this.refreshAccessToken();
        if (refreshed) {
          return this.loadRecords(true);
        }
      }
      this.setData({ loading: false });
      wx.showToast({ title: '加载失败', icon: 'error' });
    }
  },

  formatDuration(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  },

  toggleRecord(e) {
    const id = e.currentTarget.dataset.id;
    const records = this.data.records.map(r => {
      if (r.id == id) r.selected = !r.selected;
      return r;
    });
    const selectedCount = records.filter(r => r.selected).length;
    this.setData({ records, selectedCount });
  },

  async doMerge(retried = false) {
    const ids = this.data.records.filter(r => r.selected).map(r => String(r.id));
    if (ids.length < 2) {
      wx.showToast({ title: '请选择至少 2 条', icon: 'none' });
      return;
    }
    this.setData({ merging: true });
    
    try {
      const res = await api.mergeAndUpload({ record_ids: ids, format: 'gpx' }, this.data.token);
      this.setData({ mergeResult: res, merging: false });
      
      if (res.success) {
        wx.showToast({ title: '合并成功', icon: 'success' });
      } else {
        wx.showToast({ title: '合并成功，上传失败', icon: 'none' });
      }
    } catch (e) {
      if (!retried && e && e.statusCode === 401) {
        const refreshed = await this.refreshAccessToken();
        if (refreshed) {
          return this.doMerge(true);
        }
      }
      wx.showToast({ title: '合并失败', icon: 'error' });
    } finally {
      this.setData({ merging: false });
    }
  },

  async doDownload(retried = false) {
    const ids = this.data.records.filter(r => r.selected).map(r => String(r.id));
    if (ids.length < 2) {
      wx.showToast({ title: '请选择至少 2 条', icon: 'none' });
      return;
    }
    try {
      const res = await api.mergeDownload({ record_ids: ids, format: 'gpx' }, this.data.token);
      wx.openDocument({
        filePath: res.filePath,
        fileType: 'gpx',
        success: () => wx.showToast({ title: '文件已打开' }),
        fail: () => wx.showToast({ title: '下载成功', icon: 'success' })
      });
    } catch (e) {
      if (!retried && e && e.statusCode === 401) {
        const refreshed = await this.refreshAccessToken();
        if (refreshed) {
          return this.doDownload(true);
        }
      }
      wx.showToast({ title: '下载失败', icon: 'error' });
    }
  },

  resetMerge() {
    const records = this.data.records.map(r => ({ ...r, selected: false }));
    this.setData({ records, selectedCount: 0, mergeResult: null });
  }
});
