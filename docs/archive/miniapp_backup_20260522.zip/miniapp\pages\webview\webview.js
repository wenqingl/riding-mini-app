Page({
  data: {
    url: ''
  },

  onLoad(options) {
    const url = options.url ? decodeURIComponent(options.url) : wx.getStorageSync('auth_url');
    if (url) {
      this.setData({ url });
    }
  },

  onMessage(e) {
    const dataList = (e.detail && e.detail.data) ? e.detail.data : [];
    const last = dataList.length ? dataList[dataList.length - 1] : {};
    const accessToken = last.access_token || last.token || '';
    const refreshToken = last.refresh_token || '';

    if (accessToken) {
      wx.setStorageSync('access_token', accessToken);
      if (refreshToken) {
        wx.setStorageSync('refresh_token', refreshToken);
      }
      wx.showToast({ title: 'Login success', icon: 'success' });
      wx.navigateBack();
    }
  },

  onError() {
    wx.showToast({ title: 'Load failed', icon: 'error' });
  }
});
